#It's the blog for TautCony

###Hope I could write some interesting things here.