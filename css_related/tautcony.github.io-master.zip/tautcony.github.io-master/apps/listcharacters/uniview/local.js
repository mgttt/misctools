var _local = true; // change to false when uploading to server; affects location character data is pulled from
